#include <stdio.h>
#include "hello_top.h"

unsigned char hello_fun(void)
{
    printf("hello_world~\n");
    return 0;
}



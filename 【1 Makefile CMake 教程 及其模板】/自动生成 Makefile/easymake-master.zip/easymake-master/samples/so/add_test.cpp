#include <iostream>
#include "math/add.h"

using namespace std;

int main(){
	cout<<"add(8,8)="<<add(8,8)<<endl;
}

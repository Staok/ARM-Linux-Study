#ifndef __HEADER_H__

#define MAX(a, b)  	((a) > (b)? (a) : (b))
#define SAFE_DELETE(_ptr) if( NULL != (_ptr) ) { delete (_ptr);}

#endif//__HEADER_H__

#include <stdio.h>
#include "myMath_fn.h"

void myAdd(unsigned int a, unsigned int b)
{
    printf("%d + %d = %d\n", a, b, a + b);
}



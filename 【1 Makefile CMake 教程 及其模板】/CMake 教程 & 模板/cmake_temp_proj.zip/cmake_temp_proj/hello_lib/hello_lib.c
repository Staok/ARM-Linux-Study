#include <stdio.h>
#include "hello_lib.h"

unsigned char hello_fun(void)
{
    printf("hello_world~");
    return 0;
}



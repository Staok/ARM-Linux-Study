#ifndef __HELLO_LIB_H__
#define __HELLO_LIB_H__

unsigned char hello_fun(void);

#endif


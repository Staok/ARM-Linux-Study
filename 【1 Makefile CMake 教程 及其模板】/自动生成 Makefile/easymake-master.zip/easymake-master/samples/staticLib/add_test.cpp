#include "math/add.h"

#include <iostream>

using namespace std;

int main(){
	cout<<"add(8,8)="<<add(8,8)<<endl;
  return 0;
}

#include "hello_top2.h"

int main(int argc, char *argv[])
{
    hello_fun2();
    return 0;
}



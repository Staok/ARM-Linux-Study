#include <iostream>
using std::cout;
using std::endl;

int hello_world(){
	cout<<"hello world"<<endl;
}

#include <iostream>

#include "math/add.h"

int main(){
  std::cout<<"add(5,6) returns "<<add(5,6)<<std::endl;
}


#include <stdio.h>
#include "hello_top2.h"

unsigned char hello_fun2(void)
{
    printf("hello_world~~~~~~~~~~~~~~\n");
    return 0;
}




#define B  2
void sub2_fun(void); 


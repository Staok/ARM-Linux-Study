int hello_world();
int main(){
	hello_world();
}

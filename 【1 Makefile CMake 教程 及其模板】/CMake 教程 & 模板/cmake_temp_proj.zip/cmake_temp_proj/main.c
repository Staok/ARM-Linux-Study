#include "hello_lib.h"



int main(int argc, char *argv[])
{
    return hello_fun();
}



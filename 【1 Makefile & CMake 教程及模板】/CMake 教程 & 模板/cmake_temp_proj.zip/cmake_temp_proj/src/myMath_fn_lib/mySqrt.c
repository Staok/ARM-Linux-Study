#include <stdio.h>
#include "myMath_fn.h"

void mySqrt(unsigned int a, unsigned int b)
{
    printf("%d / %d = %f.2\n", a, b, (double)a / (double)b);
}



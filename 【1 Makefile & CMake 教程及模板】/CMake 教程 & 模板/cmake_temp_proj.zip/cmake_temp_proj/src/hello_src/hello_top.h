#ifndef __HELLO_TOP_H__
#define __HELLO_TOP_H__

unsigned char hello_fun(void);

#endif


#include <iostream>
#include "fmt/format.h"

int main(int argc, const char *argv[])
{
  fmt::print("Hello, {}!\n", "world");
  return 0;
}


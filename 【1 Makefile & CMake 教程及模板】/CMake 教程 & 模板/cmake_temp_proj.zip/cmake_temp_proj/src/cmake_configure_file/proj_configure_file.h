// the configured options and settings for Proj
#define PROJ_VERSION_MAJOR 0
#define PROJ_VERSION_MINOR 1
#define PROJ_VERSION_PATCH 0

#define TIMESTAMP "2023.09.06-22:56:15"

#define USE_HELLO_SRC2

#define CMAKE_DEFINE_1 ON
#define CMAKE_DEFINE_2 0
#define CMAKE_DEFINE_3 "aaa"

#include <stdio.h>
#include <stdlib.h>

#include "proj_configure_file.h"

#include "hello_top.h"

#ifdef USE_HELLO_SRC2
    #include "hello_top2.h"
#else

#endif

#include "myMath_fn.h"



int main(int argc, char *argv[])
{
    hello_fun();

    #ifdef USE_HELLO_SRC2
        hello_fun2();
    #endif

    myAdd(1, 1);
    return 0;
}



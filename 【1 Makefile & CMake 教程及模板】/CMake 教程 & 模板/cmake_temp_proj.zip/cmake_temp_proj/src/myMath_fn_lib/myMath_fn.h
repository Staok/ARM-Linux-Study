#ifndef __MYMATH_FN_LIB_H__
#define __MYMATH_FN_LIB_H__

void myAdd(unsigned int a, unsigned int b);
void mySqrt(unsigned int a, unsigned int b);

#endif
#ifndef __CLASS_A_H__
#define __CLASS_A_H__
#include<iostream>

class ClassA
{
public:
	ClassA();
	~ClassA();
public:
	void print();
	

};
#endif//__CLASS_A_H__

#ifndef __HELLO_TOP_TWO_H__
#define __HELLO_TOP_TWO_H__

unsigned char hello_fun2(void);

#endif


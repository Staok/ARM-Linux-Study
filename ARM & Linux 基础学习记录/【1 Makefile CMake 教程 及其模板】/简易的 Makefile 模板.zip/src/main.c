#include <stdio.h>
#include "add.h"
#include "sub.h"
//#include "add1.h"

int main()
{
	printf("100 ask, add:%d\n", add(10, 10));
	printf("100 ask, sub:%d\n", sub(20, 10));
	
	//printf("100 ask, add1:%d\n", add1(4, 1));
	
	return 0;
}
